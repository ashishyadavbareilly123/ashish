<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php echo base_url()?>assets/login.css">
        <title>Bootstrap 5 Login Form Example</title>        
    </head>
    <body>
     <div class="container">
            <h1 style = "padding-bottom: 26px";>Admin Form</h1>
            <?php if($msg = $this->session->flashdata('invailid_up')){?>
                <div class="loginMsg">
                    <p><?php echo $msg?></p>
                </div>
                <?php } ?>
                <?php echo form_open('admin/login/user_login'); ?>
                <div class= "row">
                    <div class="form-group">
                        <label for="uname" style="margin-right: 344px;">Username</label>
                        <?php echo form_input(['class' => "form-control", 'id'=>'uname' ,'placeholder' => 'Enter username', 'name' => 'username','value' => set_value('username'),'autocomplete'=>"on"]); ?>
                    </div>
                    <div class="">
                        <?php echo form_error('username'); ?>
                    </div>
                </div>
                <div class= "row">
                    <div class="form-group">
                        <label for="pass" style="margin-right: 344px;">Password</label>
                        <?php echo form_password(['class' => 'form-control', 'id'=>'pass' , 'placeholder' => 'Enter Password', 'name' => 'password', 'value' => set_value('password')]); ?>
                    <div class="">
                        <?php echo form_error('password'); ?>
                    </div>
                </div>
                <?php echo form_submit(['class' => 'btn btn-primary', 'value' => 'Submit']); ?>
                <?php echo form_reset(['class' => 'btn btn-default', 'value' => 'Reset']); ?>
                <?php echo anchor('admin/login','Sign up?', 'class="link-class"'); ?>
            </div>
</div>
    </body>

</html>