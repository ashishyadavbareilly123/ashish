<?php
$config = [
	//add_article_rules form ka name h
	'add_article_rules' => [
		[
			'field' => 'article_title',
			'lable' => 'Article Title',
			'rules' => 'required',
		],
		[
			'field' => 'article_body',
			'lable' => 'Article Body',
			'rules' => 'required',
		],
	],
	'login_rules' => [
		[
			'field' => 'username',
			'lable' => 'Username',
			'rules' => 'required',
		],
		[
			'field' => 'password',
			'lable' => 'Password',
			'rules' => 'required',
		],
	],
	'article_register_rules' => [
		[
			'field' => 'username',
			'lable' => 'Username',
			'rules' => 'required',
		],
		[
			'field' => 'password',
			'lable' => 'Password',
			'rules' => 'required',
		],
		[
			'field' => 'fname',
			'lable' => 'First Name',
			'rules' => 'required',
		],
		[
			'field' => 'lname',
			'lable' => 'Last Name',
			'rules' => 'required',
		],
		[
			'field' => 'email',
			'lable' => 'Email',
			'rules' => 'required|valid_email',
		],
	],
];

?>