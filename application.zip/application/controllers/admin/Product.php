<?php
class Product extends MY_Controller {
    public function total_stock_list(){
        $this->load->model('product_model');
        $total_stock = $this->product_model->TotalStock();
        $this->load->view('admin/header');
        $this->load->view('admin/total_stock_page',['stock_list'=>$total_stock]);
    }

    public function create_order() {
        $this->load->model('product_model');
        $list = $this->product_model->get_product();    

        $this->load->view('admin/header');
        $this->load->view('admin/generate_order',['product_lists'=>$list]);
    }

    public function get_select_product_price(){
        $this->load->model('product_model');
        $product_id = $this->input->post('product_id');
        $arr = $this->product_model->get_product_price($product_id);
        if($arr){
            $price = $arr[0]['fld_product_price'];
            echo $price;
        }else{
            echo "failed";
        }       
    }

}

?>