<?php
class Order_model extends CI_model{
public function order($pid,$qty,$array){
    $this->db->select("*");
    $this->db->from('tbl_product');
    $this->db->where(['fld_product_id'=>$pid]);
    $arr = $this->db->get();
    $stock = $arr->result_array();
    $totalStock = $stock[0]['fld_total_stock'];

    if($totalStock >= $qty){
       $updateStock = $totalStock-$qty;

       $data = array(
        'fld_total_stock' => $updateStock,
        );
        $this->db->where('fld_product_id', $pid);
        $this->db->update('tbl_product',$data);

       $this->db->insert('tbl_order', $array);
       return $this->db->insert_id();
    }else{
        return 'false';
    }
  }

  public function bill_list(){
    $this->db->select("*");
    $this->db->from('tbl_order');
    $this->db->where(['fld_order_status'=> '1']);
    $arr = $this->db->get();
    return $arr->result_array();
  }
}
?>