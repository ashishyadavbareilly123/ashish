<?php
class Login_model extends CI_model{
    public function signIn($username, $pass) {
        $this->db->where(['fld_admin_name'=> $username,'fld_password'=>$pass]);
        $admin = $this->db->get('tbl_admin');
        return $admin->result_array();
	}
}
?>