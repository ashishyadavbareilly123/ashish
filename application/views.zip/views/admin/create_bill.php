<!DOCTYPE html>
<html lang="en">
<head>
  <title>Total Stock</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/create_bill.css">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;700;900&family=Roboto:wght@100&display=swap" rel="stylesheet">
</head>
<body>
<div class="header">
    <h2>Print or Generate Inventory Bill</h2>
</div>
<div class="container">
  <table class="table table-hover mt-4">
    <thead>
      <tr>
        <th>ID</th>
        <th>Product Name</th>
        <th>Product Qty</th>
        <th>Product Price</th>
        <th>Sub Total</th>
      </tr>
    </thead>
    <tbody>
        <?php if(!empty($order_lists)) { $id = 0;?>
        <?php foreach($order_lists as $list) { $id++ ?>
      <tr>
       <td><?php  echo $id ?></td>
        <td><?php echo $list['fld_product_name']?></td>
        <td><?php echo $list['fld_product_qty']?></td>
        <td><?php echo $list['fld_product_price']?></td>
        <td><?php echo $list['fld_sub_total']?></td>
        <?php } } else {?>
          
      </tr>
    </tbody>
  </table>
  <h1 style = "text-align:center">Data not available</h1>
        <?php } ?>
</div>
<div><button onclick="window.print()" class = "btn btn-primary printbtn" style="
    position: absolute;
    margin-top: 128px;
">Print</button></div>
</body>
</html>
