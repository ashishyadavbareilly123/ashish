<?php
class Order extends MY_Controller{
    public function generate_bill(){
        $this->load->view('admin/header');
        $this->load->view('admin/generate_order');
    }

    public function order_generate(){
       $product = $this->input->post('product');
       $qty = $this->input->post('qty');
       $price = $this->input->post('price');
       $id = $this->input->post('hiddenField');
       $hiddenName = $this->input->post('product_name');
       $created = date("Y-m-d H:i:s");
	   $status = '1';
       $sub_total = $price*$qty;
       $data = [
        'fld_product_name' => $hiddenName,
        'fld_product_qty' => $qty,
        'fld_product_price' => $price,
        'fld_sub_total' => $sub_total,
        'fld_order_status' => $status,
        'fld_created_at' => $created,
    ];
       $this->load->model('order_model');
       $id =  $this->order_model->order($id,$qty,$data);
       if($id == 'false'){
           echo "Quantity is less greater then your stock";
       }else {
           echo "Success";
       }

    }

    public function show_order_list(){
        $this->load->model('order_model');
        $list = $this->order_model->bill_list();
        $this->load->view('admin/header');
        $this->load->view('admin/create_bill',['order_lists' => $list]);
    }
}

?>