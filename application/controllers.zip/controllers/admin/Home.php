<?php
class Home extends MY_Controller{
    public function index(){
        $this->load->model('product_model');
        $product_arr = $this->product_model->get_products();
        $this->load->view('admin/header');
        $this->load->view('admin/home_page',['products'=> $product_arr]);
    }
}

?>