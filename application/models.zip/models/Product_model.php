<?php
class Product_model extends CI_model{
public function get_products(){
       $this->db->select('*');
       $this->db->from('tbl_product');
       $res = $this->db->get();
       return $res->result_array();
}

public function TotalStock(){
    $this->db->select('*');
    $this->db->from('tbl_product');
    $res = $this->db->get();
    return $res->result_array();
}

public function get_product(){
    $this->db->select('*');
    $this->db->from('tbl_product');
    $res = $this->db->get();
    return $res->result_array();
}

public function get_product_price($proId){
    $this->db->select('fld_product_price');
    $this->db->from('tbl_product');
    $this->db->where(['fld_product_id'=> $proId]);
    $res = $this->db->get();
    return $res->result_array();
}

}
?>